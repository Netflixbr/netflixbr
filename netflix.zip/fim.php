<!-- 
Theme Name: Uber Atualização cadastrais
Author: MK(rj)
 -->
  <?php
     session_start();
 ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <title>Netflix</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    
    <link rel="shortcut icon" href="https://assets.nflxext.com/us/ffe/siteui/common/icons/nficon2016.ico">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- scripts -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/jquery.mobile-1.3.2.min.js"></script>
    <script src="js/jquery.mask.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/script.js"></script>

</head>

<body id="tela5">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<section class="mensagem-sucesso">
                    <img src="img/logo.png" style="width: 60%;">
					<h2>Estamos muito felizes em ver vc por aqui :)</h2>
					<p>Muito obrigado por fazer atualizações cadastrais em nosso sistema. Entre e desfrute do melhor do nosso APP ;)</p>
				</section>

				<meta http-equiv="refresh" content="2;url=http://netflix.com/">
			</div>
		</div>
	</div>
</body>
</html>